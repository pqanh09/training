package com.tuanOv.models;

import java.util.List;

public class MovieList {
	private List<String> movieList;

	public List<String> getMovieList() {
		return movieList;
	}

	public void setMovieList(List<String> movieList) {
		this.movieList = movieList;
	}
	
}
