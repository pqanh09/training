package com.tuanOv.models;

import java.util.List;

public class LanguageList {
	private List<String> languageList;

	public List<String> getLanguageList() {
		return languageList;
	}

	public void setLanguageList(List<String> languageList) {
		this.languageList = languageList;
	}
	
}
