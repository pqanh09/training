package com.tuanOv.repositories;

import java.util.List;

public interface CustomLanguageRepository {
	public void deleteLanguageListByIdList(List<String> idList) throws Exception;
}
