package com.ov.repository;

import com.ov.model.Song;


public interface SongRepositoryCustom{
//	public interface SongDAO extends GeneralDao<Song>{

}
