package com.ov.repository;

import com.ov.model.Song;

public interface SongRepository extends GeneralRepository<Song>, SongRepositoryCustom{

}
