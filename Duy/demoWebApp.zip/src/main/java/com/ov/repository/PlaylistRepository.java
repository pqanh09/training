package com.ov.repository;


import com.ov.model.Playlist;

//public interface PlayListRepository extends GeneralRepository<Playlist>,PlayListRepositoryCustom{
	public interface PlaylistRepository extends GeneralRepository<Playlist>, PlaylistRepositoryCustom{
	
	

}
