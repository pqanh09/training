package com.ov.repository;

import java.util.List;

import com.ov.model.Playlist;

public interface PlaylistRepositoryCustom{
//	public interface PlayListDao extends GeneralDao<Playlist>{
//	List<Playlist> quey(String id);
}
