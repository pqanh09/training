package com.ov.utils;

public class ResponseSongManager extends ResponseGeneral{
	public static ResponseGeneral responseBuilder(){
		return new ResponseSongManager();
	}
}
