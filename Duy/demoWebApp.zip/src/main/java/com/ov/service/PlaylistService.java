package com.ov.service;

import com.ov.model.Playlist;
import com.ov.utils.ResponseGeneral;

public interface PlaylistService extends GeneralService<Playlist>{
//	ResponseGeneral handleGetPlaylistsBySongId(String id);
}
