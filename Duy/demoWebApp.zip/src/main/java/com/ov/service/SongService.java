package com.ov.service;

import com.ov.model.Song;

public interface SongService extends GeneralService<Song>{
//	ResponseGeneral handleGetSongsByPlaylistId(String playlistId);

}
